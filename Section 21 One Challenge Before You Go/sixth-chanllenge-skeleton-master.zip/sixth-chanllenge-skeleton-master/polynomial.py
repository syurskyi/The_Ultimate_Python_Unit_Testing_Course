class Polynomial:
    def __init__(self, terms: list):
        # Todo: Implement me
        pass

    # This method is going to multiply two Polynomial objects.
    def multiply(self, s_poly_obj):
        # Todo: Implement me
        pass

    def __len__(self):
        # Todo: Implement me
        pass

    def get_result(self):
        # Todo: Implement me
        pass

    def get_poly(self):
        # Todo: Implement me
        pass

    # This method is going to format the answer.
    def print_poly(self):
        # Todo: Implement me
        pass
