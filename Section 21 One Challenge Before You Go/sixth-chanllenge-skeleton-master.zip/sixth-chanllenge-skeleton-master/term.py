class Term:
    def __init__(self, coefficient, power):
        # Todo: Implement me
        pass

    def get_power(self):
        # Todo: Implement me
        pass

    def get_coefficient(self):
        # Todo: Implement me
        pass
